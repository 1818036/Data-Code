#*************  Code*************
#### 0.Prepare the environment ####
#Download and load the R package “haven” for reading xpt files.
#install.packages("haven")
#install.packages('plyr') 
#install.packages('dplyr')
library(haven)
library(utils)
library(forcats)
library(gtsummary)
library(tidyverse)
library(tidyr) 
library(readr) 
library(ggplot2)
library(rms) 
library(plyr)
library(dplyr)
library(arsenal) 
#For analysis under weighted conditions.
library(survey)
setwd("D:/yanjiusheng/Nhanes/zuixin/lianxi/2015-2018") 
####  I. Data extraction and derivation. ####
#### 1. Locate the data module and variables to obtain the source data. ####
##### 1.1 DEMO - Demographic data extraction#####
#Extract Component files.
demo.i <- read_xpt("DEMO_I.XPT")
demo.j <- read_xpt("DEMO_J.XPT")
#Extract the variables needed for the study
# Age - RIDAGEYR; Gender - RIAGENDR; Ethnicity - RIDRETH3; Education level - DMDEDUC2; Poverty level - INDFMPIR; Marital status - DMDMARTL
demo.data.file <- dplyr::bind_rows(list(demo.i, demo.j))
dim(demo.data.file)
demo.data <- demo.data.file[,c('SEQN', 'RIDAGEYR', 'RIAGENDR', 'RIDRETH3', 'DMDEDUC2','INDFMPIR','DMDMARTL')]

##### 1.2 PAQ - Physical Activity Questionnaire data extraction ##########
#Extract Component files.
paq.i <- read_xpt("PAQ_I.XPT")
paq.j <- read_xpt("PAQ_J.XPT")
#Extract the variables needed for the study
paq.data.file <- dplyr::bind_rows(list(paq.i, paq.j))
paq.data <- paq.data.file[,c('SEQN', 'PAQ650','PAQ665')]

##### 1.3 BMI data extraction ##########
#Extract Component files.
bmx.i <- read_xpt("BMX_I.XPT")
bmx.j <- read_xpt("BMX_J.XPT")
# 2. Extract the necessary variables for the study: BMI - BMXBMI; Waist circumference - BMXWAIST
bmx.data.file <- dplyr::bind_rows(list(bmx.i, bmx.j))
bmx.data <- bmx.data.file[,c('SEQN', 'BMXBMI', 'BMXWAIST')]

##### 1.4 SMQ - Smoking Module data extraction ######
#Extract Component files.
smq.i <- read_xpt("SMQ_I.XPT")
smq.j <- read_xpt("SMQ_J.XPT")
#Extract the variables needed for the study
# Whether smoked at least 100 cigarettes - SMQ020; Current smoking status - SMQ040; 
#How many days ago did you quit smoking - SMQ050Q; Time unit for how many days ago quit smoking (days, weeks, months, years) - SMQ050U
smq.data.file <- dplyr::bind_rows(list(smq.i, smq.j))
smq.data <- smq.data.file[,c('SEQN',"SMQ020", 'SMQ040', 'SMQ050Q', 'SMQ050U')]

#####1.5 Diabetes diagnosis  #####
######1.5.1 Glycated hemoglobin A1C (%) ###### 
ghb.i <- read_xpt("GHB_I.XPT")
ghb.j <- read_xpt("GHB_J.XPT")
ghb.data.file <- dplyr::bind_rows(list(ghb.i, ghb.j))
ghb.data <- ghb.data.file[,c('SEQN','LBXGH')]

######1.5.2 Fasting blood glucose (mg/dL)###### 
glu.i <- read_xpt("GLU_I.XPT")
glu.j <- read_xpt("GLU_J.XPT")
glu.data.file <- dplyr::bind_rows(list(glu.i, glu.j))
colnames(glu.data.file)
glu.data <- glu.data.file[,c('SEQN','LBXGLU')]

###### 1.5.3 Diabetes, use of insulin ###### 
diq.i <- read_xpt("DIQ_I.XPT")
diq.j <- read_xpt("DIQ_J.XPT")
diq.data.file <- dplyr::bind_rows(list(diq.i, diq.j))
colnames(diq.data.file)
diq.data <- diq.data.file[,c('SEQN','DIQ010','DIQ050')]

#LBXGH,LBXGLU
diabetes <- plyr::join_all(list(ghb.data, glu.data, diq.data))
dim(diabetes) 
# (a) hemoglobin A1C concentration >= 6.5% ***or*** a fasting plasma glucose level >= 126 mg/dL [21]; 
diabetes.a.index <- ifelse(diabetes$LBXGH >= 6.5 | diabetes$LBXGLU >= 126, 1, NA)
diabetes.b.index <- ifelse(diabetes$DIQ010 == 1 | diabetes$DIQ050 == 1, 1, NA)
table(diabetes.a.index) 
table(diabetes.b.index) 
diabetes.index <- ifelse(diabetes.a.index == 1| diabetes.b.index == 1, 1, 0)
diabetes.index.test <- ifelse(diabetes.a.index == 1 & diabetes.b.index == 1, 1, 0)
table(diabetes.index.test) 
table(diabetes.index) 
diabetes$diabetes.index <- diabetes.index
#It seems like you are referring to a process of creating a new variable for diabetes diagnosis based on several other variables, 
#but ultimately deciding not to use it due to a high rate of missing data for the insulin variable. 
#Instead, the diabetes diagnosis is based on a single question, ‘DIQ010’, which asks whether a doctor has informed


##### 1.6 Extraction of Blood Cadmium and Urine Cadmium  ##########
# Blood Cadmium
pbcd.i <- read_xpt("PBCD_I.XPT")
pbcd.j <- read_xpt("PBCD_J.XPT")
Ca_blooddata.file <- dplyr::bind_rows(list(pbcd.i, pbcd.j))
Ca_blooddata <- Ca_blooddata.file[,c('SEQN',"LBXBCD")]
#Urine Cadmium
um.i <- read_xpt("UM_I.XPT")
um.j <- read_xpt("UM_J.XPT")
Ca_urinedata.file <- dplyr::bind_rows(list(um.i, um.j))
Ca_urinedata <- Ca_urinedata.file[,c('SEQN',"URXUCD")]
######1.6.1 Urine Creatinine######
ALB_CR_I <- read_xpt("ALB_CR_I.XPT")
ALB_CR_J <- read_xpt("ALB_CR_J.XPT")
CR_urinedata.file <- dplyr::bind_rows(list(ALB_CR_I, ALB_CR_J))
colnames(CR_urinedata.file)
#URXUMS - Albumin, urine (mg/L)
CR_urinedata <- CR_urinedata.file[,c('SEQN',"URXUMS","URXUCR")]
##### 1.7 hs-CRP,vitD#####
###### 1.7.1 hscrp######
hscrp.i<- read_xpt("HSCRP_I.XPT")
hscrp.j<- read_xpt("HSCRP_J.XPT")
hscrp.data.file <- dplyr::bind_rows(list(hscrp.i, hscrp.j))
colnames(hscrp.data.file)
tab.crp.d <- tableby( ~ LBXHSCRP,
                      data=hscrp.data.file) 
summary(tab.crp.d, text=TRUE)
crp.data <- hscrp.data.file[,c("SEQN", "LBXHSCRP")]
######1.7.2 vitD######
vid.i <- read_xpt("VID_I.XPT")
vid.j <- read_xpt("VID_J.XPT")
vid.data.file <- dplyr::bind_rows(list(vid.i, vid.j))
colnames(vid.data.file)
vid.data <- vid.data.file[,c('SEQN',"LBXVIDMS","LBXVD2MS","LBXVD3MS","LBXVE3MS")]

##### 1.8 HDL、LDL TG TC#####
hdl.i <- read_xpt("HDL_I.XPT")
hdl.j <- read_xpt("HDL_J.XPT")
hdl.data.file <- dplyr::bind_rows(list(hdl.i, hdl.j))
hdl.data <- hdl.data.file[,c('SEQN',"LBDHDD")]

trigly.i <- read_xpt("TRIGLY_I.XPT")
trigly.j <- read_xpt("TRIGLY_J.XPT")
ldltg.data.file <- dplyr::bind_rows(list(trigly.i, trigly.j))
ldltg.data <- ldltg.data.file[,c('SEQN',"LBXTR","LBDLDL")]

tchol.i <- read_xpt("TCHOL_I.XPT")
tchol.j <- read_xpt("TCHOL_I.XPT")
tc.data.file <- dplyr::bind_rows(list(tchol.i, tchol.j))
tc.data <- tc.data.file[,c('SEQN',"LBXTC")]

##### 1.9 BPQ #####
bpq.i <- read_xpt("BPQ_I.XPT")
bpq.j <- read_xpt("BPQ_J.XPT")
bpq.data.file <- dplyr::bind_rows(list(bpq.i, bpq.j))
tab.bpq <- tableby( ~ BPQ020,
                    data=bpq.data.file) 
summary(tab.bpq, text=TRUE)
bpq.data <- bpq.data.file[,c("SEQN", "BPQ020")]
#Extract the measured three blood pressure values.
bpx.i <- read_xpt("BPX_I.XPT")
bpx.j <- read_xpt("BPX_J.XPT")
bpx.data.file <- dplyr::bind_rows(list(bpx.i, bpx.j))
colnames(bpx.data.file )
bpx.data <-bpx.data.file[,c("SEQN",
                            "BPXSY1", "BPXDI1", "BPXSY2", "BPXDI2", "BPXSY3","BPXDI3")]

##### 1.10 drinking data #####
  # Alcohol variables included in the 2015-2016 data: https://wwwn.cdc.gov/Nchs/Nhanes/2015-2016/ALQ_I.htm
  # Drinking at least 12 glasses of alcohol per year - ALQ101
  # Has ever drunk 12 or more glasses of alcohol in a lifetime - ALQ110;
  # How often did you drink alcohol in the past 12 months - ALQ120Q
  # Unit of frequency for past 12 months alcohol consumption (weeks, months, years) - ALQ120U;
  # Note: The above are the specific definitions of alcohol variables for most years, and these variables were also used to define drinking in 15-16.
  # In 17-18, drinking was defined by the following variables:
  # ALQ111_ In {your/SP}'s lifetime, {have you ever/he/she} drunk at least one glass of any type of alcohol?
  # ALQ121_ In the past 12 months, how often did {you/SP} drink any type of alcohol beverage?
  # ALQ151_ In {your/SP}'s life, have there been times when {you/he/she} almost drank every day {display number} or more types of alcoholic beverages?
  # The link to the interpretive document for this data is as follows: https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/P_ALQ.htm
###### 1.10.1 Extraction of drinking data for 15-16 ######
alq.i <- read_xpt("ALQ_I.XPT")
alq.data.i <- alq.i[,c('SEQN', 'ALQ101', 'ALQ110', 'ALQ120Q', 'ALQ120U')]
colnames(alq.data.i)
ddply(alq.data.i, .(ALQ101, ALQ110), summarize, n = length(SEQN))
ori.alq.unit <- alq.data.i$ALQ120U
table(ori.alq.unit)
trans.unit.month <- ifelse(ori.alq.unit == 1, 4, 
                           ifelse(ori.alq.unit == 3, 1/12, 
                                  ifelse(ori.alq.unit == 7|ori.alq.unit == 9, NA, 1)))
alq.data.i$trans.unit.month <- trans.unit.month
colnames(alq.data.i)
ori.alq.quantity <- alq.data.i$ALQ120Q
trans.quantity.month <- ifelse(ori.alq.quantity >= 0,  
                               ori.alq.quantity * trans.unit.month, NA)
alq.data.i$trans.quantity.month <- trans.quantity.month
alq101 <-alq.data.i$ALQ101
trans.quantity.month.factor <- ifelse(trans.quantity.month >=1 & trans.quantity.month <5, '1-5 drinks/month',
                                      ifelse(trans.quantity.month >=5 & trans.quantity.month <10, '5-10 drinks/month',
                                             ifelse(trans.quantity.month >=10, '10+ drinks/month', 'wait')))
alq.data.i$trans.quantity.month.factor <- trans.quantity.month.factor

ddply(alq.data.i, .(ALQ101, trans.quantity.month.factor), summarise, n = length(SEQN))
table(trans.quantity.month.factor) 
index.1 <- which((trans.quantity.month.factor=='wait' | is.na(trans.quantity.month.factor)) & alq101 == 1) 
trans.quantity.month.factor[index.1] <- '1-5 drinks/month'
table(trans.quantity.month.factor)
alq.data.i$trans.quantity.month.factor <- trans.quantity.month.factor
ddply(alq.data.i, .(ALQ101, trans.quantity.month.factor), summarise, n = length(SEQN))
index.less.1 <- which(alq101 == 2)
trans.quantity.month.factor[index.less.1] <- 'Non-drinker'
table(trans.quantity.month.factor)
alq.data.i$alq.group <- trans.quantity.month.factor
table(alq.data.i$alq.group)
colnames(alq.data.i)
alq.data.i <- alq.data.i[,c('SEQN',"alq.group")]
###### 1.10.2 Extraction of drinking data for 17-18 ######
alq.j  <- read_xpt("ALQ_J.XPT")
alq.data.j <- alq.j[,c('SEQN', 'ALQ111', 'ALQ121', 'ALQ151')]
ddply(alq.data.j, .(ALQ111, ALQ121), summarize, n = length(SEQN))
alq.data.j$alq.group <- NA
alq.data.j$alq.group[alq.data.j$ALQ111==1 & 
                            alq.data.j$ALQ121==0] <- "1-5 drinks/month"

alq.data.j$alq.group[alq.data.j$ALQ111==1 &
                            alq.data.j$ALQ121==0 & 
                            alq.data.j$ALQ151==2] <- "Non-drinker"

alq.data.j$alq.group[alq.data.j$ALQ111==1 & 
                            alq.data.j$ALQ121 %in% c(1,2,3)] <- "10+ drinks/month"
alq.data.j$alq.group[alq.data.j$ALQ111==1 & alq.data.j$ALQ121==4] <- "5-10 drinks/month"
alq.data.j$alq.group[alq.data.j$ALQ111==1 & alq.data.j$ALQ121 %in% c(5,6,7,8)] <- "1-5 drinks/month"
alq.data.j$alq.group[alq.data.j$ALQ111==1 & alq.data.j$ALQ121 %in% c(9,10)] <- "Non-drinker"
alq.data.j$alq.group[alq.data.j$ALQ111==1 & alq.data.j$ALQ121 %in% c(77,99)] <- NA
alq.data.j$alq.group[alq.data.j$ALQ111==2 & is.na(alq.data.j$ALQ121)] <- "Non-drinker" 
alq.data.j$alq.group[is.na(alq.data.j$ALQ111) & is.na(alq.data.j$ALQ121)] <- NA
table(alq.data.j$alq.group)
alq.data.j <- alq.data.j[,c('SEQN',"alq.group")]
colnames(alq.data.j)
alq.group.file <- dplyr::bind_rows(list(alq.data.i, alq.data.j))
table(alq.group.file$alq.group)

##### 1.11 CVD #####
#mcq160f:stroke
#mcq160e:heart attack
#mcq160d:angina pectoris
#mcq160c:CHD
#mcq160b:CHF
mcq.i <- read_xpt("MCQ_I.XPT")
mcq.j <- read_xpt("MCQ_J.XPT")
mcq.data.file <- dplyr::bind_rows(list(mcq.i, mcq.j))
colnames(mcq.data.file )
heart_disease_data  <-mcq.data.file[,c('SEQN',"MCQ160B", "MCQ160C", "MCQ160D", "MCQ160E","MCQ160F")]


#### 2 Extract and analyze relevant variables (such as weights, etc.). ####
weight.data <- demo.data.file[,c('SEQN', 'WTMEC2YR')] 
weight.data$WTMEC2YR <- weight.data$WTMEC2YR/2 
survey.design.data <- demo.data.file[,c('SEQN', 'SDMVPSU', 'SDMVSTRA')]
data_frames <- list(demo.data, paq.data, bmx.data, smq.data, alq.group.file,
                    ghb.data, glu.data, diq.data, diabetes,
                    Ca_blooddata, Ca_urinedata, CR_urinedata, crp.data, vid.data,
                    hdl.data, ldltg.data, tc.data, bpq.data, bpx.data,
                    heart_disease_data, weight.data, survey.design.data)
rows_count <- lapply(data_frames, function(df) nrow(df))
names(rows_count) <- sapply(data_frames, function(df) deparse(substitute(df)))
print(rows_count)
#### 3.Merge all the above data. #### 
output <- plyr::join_all(list(demo.data, paq.data, bmx.data, smq.data,alq.group.file,
                              ghb.data, glu.data, diq.data, diabetes,
                              Ca_blooddata, Ca_urinedata,CR_urinedata,crp.data,vid.data, hdl.data,ldltg.data,tc.data, bpq.data,bpx.data,
                              heart_disease_data,weight.data,survey.design.data), by='SEQN', type='left')

output_unique <- output %>% distinct(SEQN, .keep_all = TRUE)
dim(output_unique)
output <- output_unique
dim(output)

#### 4.Summary####
paper.data<-output
dim(paper.data)
nhanes.design <- svydesign(data=paper.data[which(paper.data$WTMEC2YR > 0),], 
                           id=~SDMVPSU, strata=~SDMVSTRA, 
                           weights=~WTMEC2YR, nest=TRUE)
summary(nhanes.design)


#### 5. Derive corresponding variables. ####
##### 5.1 Demography.#####
######5.1.1 Sex######
paper.data$Sex <- ifelse(paper.data$RIAGENDR == 1, 'male', 'female')
table(paper.data$Sex)
######5.1.2 age.group ######
#'20-39 years'，'40-59 years','60-79 years','80+ years'
paper.data$age.group <- ifelse(paper.data$RIDAGEYR >= 20 & paper.data$RIDAGEYR < 40, '20-39 years',
                               ifelse(paper.data$RIDAGEYR >=40 & paper.data$RIDAGEYR < 60, '40-59 years',
                                      ifelse(paper.data$RIDAGEYR >=60 & paper.data$RIDAGEYR < 80, '60-79 years',
                                             '80+ years')))
table(paper.data$age.group)
# '20-39 years'，'40-59 years','60+ years'
paper.data$age.group1 <- ifelse(paper.data$RIDAGEYR >= 20 & paper.data$RIDAGEYR < 40, '20-39 years',
                                ifelse(paper.data$RIDAGEYR >=40 & paper.data$RIDAGEYR < 60, '40-59 years',
                                       '60+ years'))
table(paper.data$age.group1)

###### 5.1.3 race  ######
#1
table(paper.data$RIDRETH3)
race <- recode_factor(paper.data$RIDRETH3, 
                      `1` = 'Mexican American',
                      `2` = 'Other Hispanic',
                      `3` = 'Non-Hispanic White',
                      `4` = 'Non-Hispanic Black',
                      `6` = 'Non-Hispanic Asian',
                      `7` = 'Other/multiracial'
)
paper.data$race <- race
table(paper.data$race)
#2
race1 <- recode_factor(paper.data$RIDRETH3, 
                       `1` = 'Mexican American',
                       `2` = 'Other Hispanic',
                       `3` = 'Non-Hispanic White',
                       `4` = 'Non-Hispanic Black',
                       `6` = 'Other/multiracial',
                       `7` = 'Other/multiracial'
)
paper.data$race1 <- race1
table(paper.data$race1)

###### 5.1.4 education  ######
table(paper.data$DMDEDUC2)
#1
education.attainment <- recode_factor(paper.data$DMDEDUC2, 
                                      `1` = 'Less Than 9th Grade',
                                      `2` = '9-11th Grade',
                                      `3`= 'High School Grad/GED',
                                      `4`= 'Some College or AA degree',
                                      `5`= 'College Graduate or above'
)
paper.data$education.attainment <- education.attainment
table(paper.data$education.attainment)
#2
edu.group <- recode_factor(paper.data$DMDEDUC2, 
                           `1` = '<12th grade',
                           `2` = '<12th grade',
                           `3` = 'High-school graduate',
                           `4` = 'Some college or AA degree',
                           `5` = 'College graduate above'
)
paper.data$edu.group <- edu.group
table(paper.data$edu.group)
###### 5.1.5 Marital status  ######
table(paper.data$DMDMARTL)
Marital.status <- recode_factor(paper.data$DMDMARTL, 
                                `1` = 'Married or Living with partner',
                                `2` = 'Widowed or divorced or Separated',
                                `3` = 'Widowed or divorced or Separated',
                                `4` = 'Widowed or divorced or Separated',
                                `5` = 'single',
                                `6` = 'Married or Living with partner',
)
paper.data$Marital.status <- Marital.status
table(paper.data$Marital.status)
##### 5.2  Sports data.#####
table(paper.data$PAQ650)
table(paper.data$PAQ665)
paper.data$recreational.activity <- NA
paper.data$recreational.activity [paper.data$PAQ650 == 1] <- "Vigorous"
paper.data$recreational.activity [paper.data$PAQ650 == 2 & paper.data$PAQ665 == 1] <- "Moderate"
paper.data$recreational.activity [paper.data$PAQ650 == 2 & paper.data$PAQ665 == 2] <- "No or lower"  
table(paper.data$recreational.activity)
##### 5.3 BMI #####
bmiBreaks <- c(0, 18.5, 25, 30, max(paper.data$BMXBMI, na.rm = T))
bmiLabels <- c("underweight", "normal weight", "overweight", "obesity")
paper.data$bmiStatus <- cut(paper.data$BMXBMI, breaks = bmiBreaks, labels = bmiLabels, include.lowest = T)
table(paper.data$bmiStatus)
##### 5.4 SMQ#####
table(paper.data$SMQ020)
table(paper.data$SMQ040)
table(paper.data$SMQ050Q)
table(paper.data$SMQ050U)
paper.data <- mutate(paper.data, smoke.group = case_when(
  SMQ020 == 2 ~ 'Never smoker',
  SMQ020 == 1 & SMQ040 == 3 ~ 'Former smoker',
  SMQ020 == 1 & SMQ040 <= 2 ~ 'Current smoker'
))
  
table(paper.data$smoke.group)
##### 5.5  Diabetes.#####
###### 5.5.1 Whether or not it is diabetes.######
table(paper.data$DIQ010)
diabete.group <- recode_factor(paper.data$DIQ010, 
                               `1` = 'Yes',
                               `2` = 'NO',
                               `3` = 'Borderline',
)
paper.data$diabete.group <- diabete.group
table(paper.data$diabete.group)
###### 5.5.2 A1C（%）######
diabetes.a <- ifelse(paper.data$LBXGH >= 6.5, "YES", "NO")
paper.data$diabetes.a <- diabetes.a
table(paper.data$diabetes.a)
##### 5.6 Blood cadmium #####
paper.data$blood_cd_level <- ifelse(paper.data$LBXBCD < 0.6,"Normal-level",  "High-level")
table(paper.data$blood_cd_level)
summary(paper.data$LBXBCD)

##### 5.7 HSCRP、VID#####
paper.data$CRPStatus <- ifelse(paper.data$LBXHSCRP <= 1, 0, 1)
table(paper.data$Heart.disease)

##### 5.8 BPQ#####
table(paper.data$BPQ020)
BPQ.group <- recode_factor(paper.data$BPQ020, 
                           `1` = 'Yes',
                           `2` = 'NO')

##### 5.9CVD#####
table(paper.data$MCQ160B)
CHF.group <- recode_factor(paper.data$MCQ160B, 
                           `1` = 'Yes',
                           `2` = 'NO'
)
paper.data$CHF.group <- CHF.group
table(paper.data$CHF.group)
table(paper.data$MCQ160C)
CHD.group <- recode_factor(paper.data$MCQ160C, 
                           `1` = 'Yes',
                           `2` = 'NO'
)
paper.data$CHD.group <- CHD.group
table(paper.data$CHD.group)

table(paper.data$MCQ160D)
angina.group <- recode_factor(paper.data$MCQ160D, 
                              `1` = 'Yes',
                              `2` = 'NO'
)
paper.data$angina.group <- angina.group
table(paper.data$angina.group)

table(paper.data$MCQ160E)
attack.group <- recode_factor(paper.data$MCQ160E, 
                              `1` = 'Yes',
                              `2` = 'NO'
)
paper.data$attack.group <- attack.group
table(paper.data$attack.group)

table(paper.data$MCQ160F)
stroke.group <- recode_factor(paper.data$MCQ160F, 
                              `1` = 'Yes',
                              `2` = 'NO'
)
paper.data$stroke.group <- stroke.group
table(paper.data$stroke.group)
heartdisease1 <- ifelse(paper.data$MCQ160B == 1 | paper.data$MCQ160C == 1 | paper.data$MCQ160D == 1 |  
                          paper.data$MCQ160E == 1 | paper.data$MCQ160F == 1, 1, 0)
paper.data$heartdisease <- heartdisease1
table(paper.data$heartdisease)
heartdisease <- recode_factor(paper.data$heartdisease, 
                             "1"= 'Yes',
                             "0"= 'NO'
)
table(paper.data$heartdisease)
dim(paper.data)
describe(paper.data$LBXBCD)
colnames(paper.data)
total.data<-paper.data
dim(total.data)#19225 
factor_vars <- c("Sex", "age.group","age.group1","race","race1","education.attainment","edu.group",
                 "Marital.status","recreational.activity", "bmiStatus" ,"smoke.group","alq.group",
                 "diabete.group","diabetes.a" ,"blood_cd_level","CRPStatus","CHF.group","CHD.group",
                 "angina.group","attack.group","stroke.group","heartdisease")
total.data[factor_vars] <- lapply(total.data[factor_vars], as.factor)
summary(total.data)
colnames(total.data)
#### 6.screening. ####
tt <- subset.data.frame(total.data, RIDAGEYR >= 20)
dim(tt)
tt1<- subset.data.frame(total.data, RIDAGEYR >= 20&
                         (!is.na(LBXBCD)))
dim(tt1)
tt2<- subset.data.frame(total.data, RIDAGEYR >= 20&
                          (!is.na(LBXBCD))& 
                          (!is.na(URXUCD)))
dim(tt2)#3366
summary(total.data)
paper.data<- subset.data.frame(total.data, RIDAGEYR >= 20 &
                                 (!is.na(LBXBCD))&  
                                 (!is.na(URXUCD))& 
                                 (!is.na(URXUCR))& 
                                 (!is.na(education.attainment)) & 
                                 (!is.na(Marital.status))& 
                                 (!is.na(bmiStatus))&  
                                 (!is.na(BMXWAIST))& 
                                 (!is.na(LBXHSCRP))& 
                                 (!is.na(recreational.activity))&  
                                 (!is.na(smoke.group))&
                                 (!is.na(alq.group))&
                                 (!is.na(diabetes.a))&
                                 (!is.na(heartdisease))
)
dim(paper.data)#2936

Nexclude_data1 <- subset.data.frame(tt, RIDAGEYR >= 20 &
                                      (is.na(LBXBCD))|  
                                      (is.na(URXUCD))| 
                                      (is.na(URXUCR))|  
                                      (is.na(education.attainment)) | 
                                      (is.na(Marital.status))| 
                                      (is.na(bmiStatus))|  
                                      (is.na(BMXWAIST))| 
                                      (is.na(LBXHSCRP))| 
                                      (is.na(recreational.activity))| 
                                      (is.na(smoke.group))|
                                      (is.na(alq.group))|
                                      (is.na(diabetes.a))|
                                      (is.na(heartdisease))
)
dim(Nexclude_data1)
exclude_data <- Nexclude_data1
dim(exclude_data)
#Inclusion-exclusion balance test.
exclude_data$Type <- 'exclude'
paper.data$Type <- 'include'
compare.data <- dplyr::bind_rows(paper.data, exclude_data)
colnames(compare.data)
analyze.variable <- c("SEQN", "WTMEC2YR", "SDMVPSU", "SDMVSTRA","LBXBCD","blood_cd_level","URXUCD","URXUMS","URXUCR",
                      "Sex", "RIDAGEYR","age.group", "age.group1", "race1", "education.attainment","edu.group", "INDFMPIR","Marital.status",
                      "recreational.activity","smoke.group","alq.group","diabetes.a","BMXBMI","bmiStatus", "BMXWAIST","LBXHSCRP","CRPStatus",
                      "LBXVIDMS","LBXVD2MS","LBXVD3MS","LBDHDD","CHF.group","CHD.group","angina.group",
                      "attack.group" ,"stroke.group","heartdisease","Type")
compare.data  <- compare.data[, analyze.variable]
colnames(compare.data ) <- c("SEQN", "WTMEC2YR", "SDMVPSU", "SDMVSTRA","cd","cd_level","urinary_cd","urinary_Alb","urinary_CR",
                          "Sex", "Age","Age.group", "Age.group1", "Race", "Education.attainment","Edu.group", "PIR","Marital.status",
                          "Recreational.activity","Smoke.group","Alq.group","Diabetes","BMI","BMI.group", "Waist","HSCRP","CRPStatus",
                          "VIDMS","VD2MS","VD3MS","DHDD","CHF","CHD","Angina",
                          "Attack" ,"Stroke","Heart.disease","Type")
summary(compare.data)
####7.Table S1-Inclusion-exclusion balance test. ####
tab1 <- tableby(Type ~ factor(Age.group) + factor(Sex) + factor(Race)+ factor(Education.attainment )+
                  factor(Marital.status)+factor(BMI.group)+factor(Recreational.activity)+factor(Alq.group)
                +factor(Smoke.group)+factor(Diabetes)+ cd+urinary_cd+ Age + Waist+HSCRP+factor(Heart.disease),data = compare.data
)
summary(tab1)

colnames(paper.data)
analyze.variable <- c("SEQN", "WTMEC2YR", "SDMVPSU", "SDMVSTRA","LBXBCD","blood_cd_level","URXUCD","URXUMS","URXUCR",
                      "Sex", "RIDAGEYR","age.group", "age.group1", "race1", "education.attainment","edu.group", "INDFMPIR","Marital.status",
                      "recreational.activity","smoke.group","alq.group","diabetes.a","BMXBMI","bmiStatus", "BMXWAIST","LBXHSCRP","CRPStatus",
                      "LBXVIDMS","LBXVD2MS","LBXVD3MS","LBDHDD","CHF.group","CHD.group","angina.group",
                      "attack.group" ,"stroke.group","heartdisease")
paper.data <- paper.data[, analyze.variable]
colnames(paper.data) <- c("SEQN", "WTMEC2YR", "SDMVPSU", "SDMVSTRA","cd","cd_level","urinary_cd","urinary_Alb","urinary_CR",
                          "Sex", "Age","Age.group", "Age.group1", "Race", "Education.attainment","Edu.group", "PIR","Marital.status",
                          "Recreational.activity","Smoke.group","Alq.group","Diabetes","BMI","BMI.group", "Waist","HSCRP","CRPStatus",
                          "VIDMS","VD2MS","VD3MS","DHDD","CHF","CHD","Angina",
                          "Attack" ,"Stroke","Heart.disease")
dim(paper.data)

paper.data <- paper.data %>%
  mutate(adjust_urinary_cd = urinary_cd / urinary_CR)
shapiro.test(paper.data$adjust_urinary_cd)
paper.data$ln_cd <- log(paper.data$cd)
paper.data$ln_urinary_cd <- log(paper.data$adjust_urinary_cd)
colnames(paper.data)


#### II. Data pre-analysis. ####
NHANES_design <- svydesign(data = paper.data, ids = ~SDMVPSU, strata = ~SDMVSTRA, nest = TRUE, weights = ~WTMEC2YR, survey.lonely.psu = "adjust") 
paper.data$Edu.group <- factor(paper.data$Edu.group, 
                               levels = c('<12th grade', 
                                          'High-school graduate',
                                          'Some college or AA degree',
                                          'College graduate above'))
paper.data$BMI.group <- factor(paper.data$BMI.group, 
                               levels = c('underweight', 
                                         'normal weight',
                                          'overweight',
                                          'obesity'))
paper.data$Race <- factor(paper.data$Race, 
                               levels = c('Other/multiracial', 
                                          'Mexican American',
                                          'Other Hispanic',
                                          'Non-Hispanic White',
                                          'Non-Hispanic Black'))
table(paper.data$Race)
table(paper.data$Recreational.activity)
paper.data$Recreational.activity <- factor(paper.data$Recreational.activity, 
                          levels = c('No or lower',
                                     'Moderate',
                                     'Vigorous'))
table(paper.data$Smoke.group)
paper.data$Smoke.group <- factor(paper.data$Smoke.group, 
                                           levels = c('Never smoker',
                                                      'Former smoker',
                                                      'Current smoker'))
table(paper.data$Alq.group)
paper.data$Alq.group <- factor(paper.data$Alq.group, 
                                 levels = c('Non-drinker',
                                            '1-5 drinks/month',
                                            '5-10 drinks/month',
                                            '10+ drinks/month'))
table(paper.data$Marital.status)
paper.data$Marital.status <- factor(paper.data$Marital.status, 
                               levels = c('Married or Living with partner',
                                          'single','Widowed or divorced or Separated'))

NHANES_design <- svydesign(data = paper.data, ids = ~SDMVPSU, strata = ~SDMVSTRA, nest = TRUE, weights = ~WTMEC2YR, survey.lonely.psu = "adjust") 
dim(NHANES_design)
#blood cd.quantile.var
cd.quantile.res <- svyquantile(~ cd, NHANES_design, quantiles = c(0, 0.25, 0.5, 0.75, 1))
paper.data$cd.quantile.var <- cut(paper.data$cd,
                                  breaks = cd.quantile.res$cd[,'quantile'],
                                  labels = c('Q1', 'Q2', 'Q3', 'Q4'))

paper.data$cd.quantile.var[which(is.na(paper.data$cd.quantile.var))] <- 'Q1'
#urinary cd.quantile.var
urinary_cd.quantile.res <- svyquantile(~ urinary_cd, NHANES_design, quantiles = c(0, 0.25, 0.5, 0.75, 1))
paper.data$urinary_cd.quantile.var <- cut(paper.data$urinary_cd,
                                          breaks = urinary_cd.quantile.res$urinary_cd[,'quantile'],
                                          labels = c('Q1', 'Q2', 'Q3', 'Q4'))
paper.data$urinary_cd.quantile.var[which(is.na(paper.data$urinary_cd.quantile.var))] <- 'Q1'
colnames(paper.data)
table(paper.data$cd.quantile.var)
table(paper.data$urinary_cd.quantile.var)
NHANES_design <- svydesign(data = paper.data, ids = ~SDMVPSU, strata = ~SDMVSTRA, nest = TRUE, weights = ~WTMEC2YR, survey.lonely.psu = "adjust") 
colnames(NHANES_design)
#####1.Table S2-characteristic description ####
tbl_svysummary(NHANES_design,  missing = 'no',
               include = c(cd.quantile.var,urinary_cd.quantile.var,Age.group,Sex, Race, Education.attainment,Edu.group,Marital.status,
                           Recreational.activity,BMI.group,Smoke.group,Alq.group,Diabetes, 
                           cd,urinary_cd,ln_cd,ln_urinary_cd,Age,BMI, Waist,HSCRP,Heart.disease),
               statistic = list(all_continuous()  ~ "{median} ({p25}, {p75})", 
                                all_categorical() ~ "{n_unweighted} ({p}%)"))%>% 
  modify_header(all_stat_cols() ~ "**{level}**, N = {n_unweighted} ({style_percent(p)}%)")%>%
  as_flex_table() %>% 
  flextable::save_as_docx(path = 'Variable characteristic description .docx')

#####2. Table S3-Univariate logistic analysis.#####
colnames(paper.data)
NHANES_design <- svydesign(data = paper.data, ids = ~SDMVPSU, strata = ~SDMVSTRA, nest = TRUE, weights = ~WTMEC2YR, survey.lonely.psu = "adjust") 
m1 <- svyglm(Heart.disease ~ cd, design = NHANES_design,family = quasibinomial) 
tbl_regression(m1, exponentiate = TRUE) 
m3 <- svyglm(Heart.disease ~ urinary_cd, design = NHANES_design,family = quasibinomial) 
tbl_regression(m3, exponentiate = TRUE) 
m1 <- svyglm(Heart.disease ~ ln_cd, design = NHANES_design,family = quasibinomial) 
tbl_regression(m1, exponentiate = TRUE) 
m3 <- svyglm(Heart.disease ~ ln_urinary_cd, design = NHANES_design,family = quasibinomial) 
tbl_regression(m3, exponentiate = TRUE) 
m5 <- svyglm(Heart.disease ~Age , design = NHANES_design,family = quasibinomial) 
tbl_regression(m5, exponentiate = TRUE) 
m6 <- svyglm(Heart.disease ~ factor(Age.group), design = NHANES_design,family = quasibinomial) 
tbl_regression(m6, exponentiate = TRUE) 
m8 <- svyglm(Heart.disease ~ factor(Sex), design = NHANES_design,family = quasibinomial) 
tbl_regression(m8, exponentiate = TRUE) 
m9 <- svyglm(Heart.disease ~ factor(Race), design = NHANES_design,family = quasibinomial) 
tbl_regression(m9, exponentiate = TRUE) 
m11 <- svyglm(Heart.disease ~ factor(Education.attainment), design = NHANES_design,family = quasibinomial) 
tbl_regression(m11, exponentiate = TRUE) 
m14 <- svyglm(Heart.disease ~ factor(Marital.status), design = NHANES_design,family = quasibinomial) 
tbl_regression(m14, exponentiate = TRUE) 
m15 <- svyglm(Heart.disease ~ factor(Recreational.activity), design = NHANES_design,family = quasibinomial) 
tbl_regression(m15, exponentiate = TRUE) 
m16 <- svyglm(Heart.disease ~ factor(Smoke.group), design = NHANES_design,family = quasibinomial) 
tbl_regression(m16, exponentiate = TRUE) 
m17 <- svyglm(Heart.disease ~ factor(Alq.group), design = NHANES_design,family = quasibinomial) 
tbl_regression(m17, exponentiate = TRUE) 
m18 <- svyglm(Heart.disease ~ factor(Diabetes), design = NHANES_design,family = quasibinomial) 
tbl_regression(m18, exponentiate = TRUE) 
m20 <- svyglm(Heart.disease ~ factor(BMI.group), design = NHANES_design,family = quasibinomial) 
tbl_regression(m20, exponentiate = TRUE) 
m21 <- svyglm(Heart.disease ~ Waist, design = NHANES_design,family = quasibinomial) 
tbl_regression(m21, exponentiate = TRUE) 
m22 <- svyglm(Heart.disease ~ HSCRP, design = NHANES_design,family = quasibinomial) 
tbl_regression(m22, exponentiate = TRUE) 
#####3.save lasso data for JMP #####
analyze.variable <- c("ln_cd", "ln_urinary_cd","Age", "Race","Marital.status",
                      "Recreational.activity","Smoke.group","Alq.group","Diabetes",
                      "Waist","HSCRP","Heart.disease")
lasso.data <- paper.data[, analyze.variable]
colnames(lasso.data) <- c("ln_blood_cd", "ln_urinary_cd","Age","Race","Marital_status",
                          "Recreation_activity","Smoke.group","Drinking_status",
                          "Diabetes","Waist","HSCRP","CVD")
library(openxlsx)
write.xlsx(lasso.data,'LASSOdata.xlsx')

